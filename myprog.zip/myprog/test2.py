import MySQLdb

db = MySQLdb.connect(host="localhost",    
                     user="root",         
                     passwd="root",  
                     db="program1")        


cur = db.cursor()


cur.execute("SELECT * from exampl1")

for row in cur.fetchall():
    print row[0]

db.close()
