#!/usr/python/bin
import re
import MySQLdb


db = MySQLdb.connect(host="localhost",    
                     user="root",         
                     passwd="root",  
                     db="program1")        


cursor = db.cursor()


with open("/home/asm/Downloads/diag.out", "r") as ins:
    list_of_lines = []
    
    for line in ins:
           matchObj = re.match("----- APmgr info: apmgrinfo -a", line , re.M|re.I)
           if matchObj:
             for line in ins:
               list_of_lines.append(line)
               matchObj2 = re.match("----- Disconnected APs: wlaninfo --all-disc-ap -l 3", line , re.M|re.I)
               if matchObj2:
                  break

for line in list_of_lines:
     #print line
     if line == "\n":
	print "------------------------------------------------------"


aps = []

ap = []
for line in list_of_lines:
	
	if line != "\n":
		ap.append(line)
	else:
		ap = "".join(ap)
		aps.append(ap)
		ap = [] 


print len(aps)

for ap in aps:
	print ap
	print "_______________________"
       
for ap in aps:
	rip = re.search(r'/\s\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s/')
	if rip:
	#print b
		for a in rip:
			print a[1:-1]

	print "_____________________MACAddress___________________________"
	rmac = re.search(ur'([0-9a-f]{2}(?::[0-9a-f]{2}){5})', re.IGNORECASE)
	bmac = re.findall(rmac,f1)
	for mac in bmac:
		print mac
		"""res1= ("insert into exampl1(MACAddres) values ('%s');" %(mac))
		cursor.execute(res1)
		db.commit()"""

	print "___________________NAME___________________________"
	rname = re.search(ur'\s*Name\s*:\s*(.*)',re.I)
	bname = re.findall(rname,f1)
	for nam in bname:
		print nam

	print "____________________TUNNEL____________________________________"
	rtn = re.search(ur'\s*Tunnel/Sec Mode\s*:\s*(.*)',re.I)
	btn = re.findall(rtn,f1)
	for tn in btn:
		print tn[0:-6]

	print "______________________SEC MODE__________________________________"
	rsc = re.search(ur'\s*Tunnel/Sec Mode\s*:\s*(.*)',re.I)
	bsc = re.findall(rsc,f1)
	for sc in bsc:
		sc1 =sc.split('/')
		print sc1[1]

	print "______________________STATE__________________________________"
	rst = re.search(ur'\s*State\s*:\s*(.*)',re.I)
	bst = re.findall(rst,f1)
	for st in bst:
		print st
	
	print "_____________________MESH ROLE___________________________________"
	rmr = re.search(ur'\s*Mesh Role\s*:\s*(.*)',re.I)
	bmr = re.findall(rmr,f1)
	for mr in bmr:
		print mr

	print "___________________PSK_____________________________________"
	rp = re.search(ur'\s*PSK\s*:\s*(.*)',re.I)
	bp = re.findall(rp,f1)
	for psk in bp:
		print psk

	print "___________________TIMER_____________________________________"
	rt = re.search(ur'\s*Timer\s*:\s*(.*)',re.I)
	bt = re.findall(rt,f1)
	for tm in bt:
		print tm

	print "__________________HW VERSION______________________________________"
	rhw = re.search(ur'\s*HW/SW Version\s*:\s*(.*)/',re.I)
	bhw = re.findall(rhw,f1)
	for hw in bhw:
		print hw

	print "___________________SW VERSION_____________________________________"
	rsw = re.search(ur'\s*HW/SW Version\s*:\s*(.*)',re.I)
	bsw = re.findall(rsw,f1)
	for sw in bsw:
		sw1 = sw.split('/')
		print sw1[1]

	print "___________________MODEL_____________________________________"
	rm = re.search(ur'\s*Model/Serial Num\s*:\s*(.*)/',re.I)
	bm = re.findall(rm,f1)
	for md in bm:
		print md

	print "____________________SERIAL NUM____________________________________"
	rs = re.search(ur'\s*Model/Serial Num\s*:\s*(.*)',re.I)
	bs = re.findall(rs,f1)
	for sr in bs:
		sr1 = sr.split('/')
		print sr1[1]

	print "____________________IPV6 ADDRESS____________________________________"
	ripv = re.search(r'[a-fA-F\d]{4}::\d{1}')
	bipv = re.findall(ripv,f1)
	for ipv in bipv:
		print ipv
	#IPv6Address





       		"""if result1:
			print(result.group()+ '  ' + result1.group())
				#print "\t"
			res1=("insert into exampl1 (MACAddres,IPv4Address) values ('%s','%s');" % (result.group(),result1.group()))
			cursor.execute(res1)
			db.commit()"""
print "done"

		





'''print ap[8:25]
	print ap[28:43]
	print ap[46:53]
	print ap[77:87]
	print ap[111:129]
	print ap[153:156]
	print ap[180:187]
	print ap[28:43]
	print ap[28:43]
	print ap[28:43]
	print ap[28:43]
	print ap[28:43]
	print ap[28:43]
	print ap[28:43]'''




