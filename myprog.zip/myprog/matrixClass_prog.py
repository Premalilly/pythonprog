#!/usr/bin/python

 
class Matrices:
	def __init__(self):
		self.res = [] 
		#print "Matrix"
	def matrix1(self):
		num = input("Enter Value:")
		for i in range(num):
			row = []
			for j in range(num):
				k = input()
				row.append(k)
			self.res.append(row)
		print (self.res)

	def __add__(self,a1):
		res=[]
		for i in range(len(self.res)):
		    row=[]            
		    for j in range(len(self.res[0])):
		        x=self.res[i][j] + a1.res[i][j]
		        row.append(x)
		    res.append(row)
		print res
		    #rez=mat
		#return rez
	def __sub__(self,a2):
		res=[]
		for i in range(len(self.res)):
		    row=[]            
		    for j in range(len(self.res)):
		        x=self.res[i][j] - a2.res[i][j]
		        row.append(x)
		    res.append(row)            
		print res     

obj1=Matrices()
obj2=Matrices()

obj1.matrix1()
obj2.matrix1()

print obj1+obj2
print obj2-obj1
#print a*b

