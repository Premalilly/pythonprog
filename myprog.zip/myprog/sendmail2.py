import smtplib
import getpass
import MySQLdb

db = MySQLdb.connect(host="localhost",    
                     user="root",         
                     passwd="root",  
                     db="program1")        


cur = db.cursor()
cur.execute("show columns from student;")
data2=cur.fetchall()
a1 = (("%s\t%s\t %s") % (data2[0][0],data2[1][0],data2[2][0]))
print a1


cur.execute("SELECT * from student")
data1=cur.fetchall()
sr =''
#print data1
for row in data1:
	a = ("%s\t%s\t %s" % (row))
	sr=sr+a+'\n'
print sr

db.commit()	
db.close()

host = "smtp.gmail.com"
port = 587
server = smtplib.SMTP(host,port)
server.ehlo()
server.starttls()
server.ehlo()
username = raw_input("gmail")
password = getpass.getpass()
server.login(username,password)
to = raw_input("to")
sub = raw_input("Sub")
#mes = raw_input("message")
mes = a1
mes1 = sr
message = "Subject: %s \n\n %s \n %s" %(sub,mes,mes1)
server.sendmail(username,to,message)
