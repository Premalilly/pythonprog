

class Queue:
	def __init__(self):
		self.items = []
	def isEmpty(self):
	        return self.items == []
	def inqueue(self, val):
	        self.items.insert(0,val)
	
	def dequeue(self):
	        return self.items.pop()
	
	def listQueue(self):
            print self.items

q = Queue()
q.isEmpty()
q.inqueue(53)
q.inqueue(43)
q.listQueue()
q.dequeue()
q.listQueue()
q.inqueue(23)
q.inqueue(44)
q.listQueue()

	
