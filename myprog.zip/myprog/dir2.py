from os import path
import os
from datetime import datetime, timedelta

today = datetime.today()
print today

one_month = datetime.now() - timedelta(days = 30)
print one_month
for files in os.listdir("/home/asm"):
	#print files 
	file1 = datetime.fromtimestamp(path.getctime(files))
	print file1
"""file1 = datetime.fromtimestamp(path.getctime('/home/asm'))"""
	if file1 < one_month:
  		print files


