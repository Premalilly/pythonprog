class Rectangle:
	def __init__(self,width,height):
		self.width=width
		self.height=height
	def area(self):
		return self.width * self.height
	def perimeter(self):
		return 2 * (self.width + self.height)
	def __add__(self,other):
		return self.width+other.width, self.height+other.width 
obj = Rectangle(10,15);
print obj
print obj.area()
print obj.perimeter()
obj2 = Rectangle(12,13);
#print obj2.ad()
print str(obj+obj2)
