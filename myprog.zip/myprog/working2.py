#!/usr/python/bin
import re
import MySQLdb


db = MySQLdb.connect(host="localhost",    
                     user="root",         
                     passwd="root",  
                     db="program1")        


cursor = db.cursor()


with open("/home/asm/Downloads/diag.out", "r") as ins:
    list_of_lines = []
    
    for line in ins:
           matchObj = re.match("----- APmgr info: apmgrinfo -a", line , re.M|re.I)
           if matchObj:
             for line in ins:
               list_of_lines.append(line)
               matchObj2 = re.match("----- Disconnected APs: wlaninfo --all-disc-ap -l 3", line , re.M|re.I)
               if matchObj2:
                  break

for line in list_of_lines:
     #print line
     if line == "\n":
	print "------------------------------------------------------"


aps = []

ap = []
for line in list_of_lines:
	
	if line != "\n":
		ap.append(line)
	else:
		ap = "".join(ap)
		aps.append(ap)
		ap = [] 


print len(aps)

for ap in aps:
	print ap
	print "_______________________"
       
for ap in aps:
        result = re.search(ur'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})',ap,re.M)
	if result:
		result1 = re.search(ur'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})',ap,re.M)
       		if result1:
			result2 = re.search(ur'(\Name\s*:\s*(.*))',ap,re.M)
			if result2:
				st = str(result2.group())
				st1 = st.split(':')
				#print st1[1]
				result3 = re.search(ur'(\Tunnel/Sec Mode\s*:\s*(.*))',ap,re.M)
				if result3:
					stt = str(result3.group())
					stt1 = stt.split(':')
					#print (stt1[1])
					stt2 = stt1[1].split('/')
					print stt2[0]
					print stt2[1]
					
				#print(result.group()+ '  ' + result1.group()+ ' ' +str(result2.group())
				#print "\t"
			#res1=("insert into exampl1 (MACAddres,IPv4Address) values ('%s','%s');" % (result.group(),result1.group()))
			#cursor.execute(res1)
			#db.commit()
print "done"


"""name = re.compile(r'\s*Name\s*:\s*(.*)')
found = re.findall(name, file1)
for ljk in found:
        print ljk"""
#/^([0-9a-f]|:){1,4}(:([0-9a-f]{0,4})*){1,7}$/i		
