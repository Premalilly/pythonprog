#!/usr/bin/python
import re


file1 =open("/home/asm/Documents/destination.txt","r")
file2 =open("/home/asm/Documents/source.txt","r")

f1=open("matFile1",'w+')                              #matching status same
ff2=open("matFile2",'w+')                              #matching status anything   
f3=open("matFile2",'w+')                              #matching status differs  
f4=open("matFile2",'w+')                              #lines present in first but not second
f5=open("matFile2",'w+') 			       #lines present in first but not second
f6=open("matFile2",'w+')


dkey1=''
dval1=''
dkey2=''
dval2=''
dict1={}
dict2={}
list1 = []
list2 = []


print "-------source file count--2460------"
try:
	count1=0
	for line in file2:
		f2 = re.match(r'(tempest(.*))',line,re.M)
		if f2:
			#print f2.group()
			s1 = str(f2.group().strip())
			s2= s1.split(' ... ')
			#print s2[0]	
			#print s2[1]
			dkey1 = s2[0]
			dval1 = s2[1]
			dict1[dkey1] = dval1
			a = str(dkey1) + str(dval1)
			list1.append(a)
			count1 = count1 + 1
	print count1
	

except IndexError:
	#print "Out of lines"
	print count1	
#print dict1
#print list1

print "-------destination file count---2059-----"
count2 = 0
for lines in file1:
	findobj = re.match(r'(tempest(.*))',lines,re.I)
	if findobj:
		#print findobj.group()
		d1 = str(findobj.group().strip())
		d2= d1.split(' ... ')
		#print d2[1]
		dkey2 = d2[0]
		dval2 = d2[1]
		dict2[dkey2] = dval2
		b = str(dkey2) + str(dval2)
		list2.append(b)
		count2 = count2 +1
print count2
#print dict2
#print list2


print "-tempest'to matching status same (both are 'ok' or both are 'FAIL')-1663-"
countt = 0
for i in list1:
	for j in list2:
		if i==j:
			#print i
			f1.writelines(i+ '\n')
			countt = countt + 1
f1.close()
print countt


print "- matching status differs (one file have 'ok' and another has 'FAIL')-221-"
count4 = 0
for i in dict1:
	for j in dict2:
		if i==j:
			if dict1[i] != dict2[j]:
				#print i
				#print type(i)
				ff2.writelines(i+'\n')
				count4 = count4 + 1
ff2.close()
print count4


print "-matching status may be anything (the status is neither 'ok' not 'FAIL'-1884"
count = 0
for i in dict1:
	for j in dict2:
		if i==j:
			#print i
			f3.writelines(i+'\n')
			count = count + 1
f3.close()
print count


print "------matching status may be anything---87--"
count5 = 0
for i in dict1:
	for j in dict2:
		if(i==j):
			if((dict1[i]!='ok')&(dict1[i]!='FAIL'))&((dict2[j]!='ok')&(dict2[j]!='FAIL')):
				#print i,dict1[i]
				count5=count5+1
				f4.writelines(i+'\n')
            
f4.close()
print count5


print "---matching status available in first not in second--576--"
count6=0
for i in dict1:
	if i in dict2:
		continue
	else:
		count6=count6+1
		f5.writelines(i+'\n')
      		#print i
f5.close()
print count6


print "--matching status available in second but not in first-175-"		
count7=0
for j in dict2:
	if j in dict1:
		continue
	else:
		#print j
		f6.writelines(j+'\n')
		count7=count7+1
f6.close()
print count7
     		




			


