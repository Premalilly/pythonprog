

class Stack:
        def __init__(self):
            self.data = []

        def isEmpty(self):
            if len(self.data):
                return False
            else:
                return True

        def push(self, val):
            self.data.append(val)

        def pop(self):
            if not self.isEmpty():
                self.data[len(self.data)-1]
                self.data = self.data[:len(self.data)-1]
            else:
                print "Stack is empty"

        def listStack(self):
            print self.data

s = Stack()
s.push(5)
s.push(6)
s.listStack()
s.pop()
s.listStack()
s.push(20)
s.push(45)
s.push(435)
s.push(35)
s.listStack()
s.pop()
s.listStack()
s.push(10)
s.push(15)
s.listStack()

