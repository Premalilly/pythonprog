class ClassName:
	def __init__(self,a):
		self.a = a
		print "Object created"
	def __str__(self):
		return str(self.a)
	def __del__(self):
		print "Object removed"
	def sqr(self):
		return self.a**2
	def prime(self, num):
		#x = True
		if num > 1:
       			for i in (2,num):
           			if (num % i) == 0:
					print "Not a prime" 
             				break
       				else:
         				print(i)
	def __add__(self,other):
		return self.a + other.a
	def __sub__(self,other):
		return self.a - other.a
	def __mul__(self,other):
		return self.a * other.a
	
obj = ClassName(10);
obj1 = ClassName(10);
print obj
print obj.sqr()
print obj.prime(15)
print obj+obj1
print obj-obj1
print obj*obj1
del obj

#print obj

