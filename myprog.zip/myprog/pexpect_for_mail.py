import pexpect
import sys
import MySQLdb

m = pexpect.spawn('python ')
m.logfile_read = sys.stdout
m.expect("Username:")
m.sendline("premar591@gmail.com")
m.expect("Password:")
m.sendline("")
m.expect("To address :")
m.sendline("prema.r@asmltd.com")
m.expect("Subject :")
m.sendline("test")
m.expect("Enter the content. Your last line should be as 'end'")
m.sendline("hello")
m.sendline("end")
m.expect("test has been send to prema.r@asmltd.com")
m.close()
