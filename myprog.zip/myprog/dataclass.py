#!/usr/python/bin
import re
import MySQLdb

class Datacls:
	def __init__(self):
		self.db = MySQLdb.connect(host="localhost",user="root",passwd="root", db="program1")   
		print "Database Connection"     


		self.res = self.db.cursor()

	print "---------------------------------Fetching Values from File---------------------------"
	def filepar(self):
		with open("/home/asm/Downloads/diag.out", "r") as ins:
		    list_of_lines = []
		    
		    for line in ins:
			   matchObj = re.match("----- APmgr info: apmgrinfo -a", line , re.M|re.I)
			   if matchObj:
			     for line in ins:
			       list_of_lines.append(line)
			       matchObj2 = re.match("----- Disconnected APs: wlaninfo --all-disc-ap -l 3", line , re.M|re.I)
			       if matchObj2:
				  break

		for line in list_of_lines:
		     #print line
		     if line == "\n":
			print "------------------------------------------------------"


		aps = []

		ap = []
		for line in list_of_lines:
	
			if line != "\n":
				ap.append(line)
			else:
				ap = "".join(ap)
				aps.append(ap)
				ap = [] 


		print len(aps)

		for ap in aps:
			print ap
			print "_______________________"
		       
		for ap in aps:
			print "------------------------Mac Address------------------"
			rmac = re.search(ur'([0-9a-f]{2}(?::[0-9a-f]{2}){5})',ap,re.M)
			if rmac:
				rmac = str(rmac.group())
				print rmac

			print "------------------------IPV4 Address------------------"
			rip = re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',ap,re.M)
			if rip:
				rip=str(rip.group())
				print rip

			print "------------------------IPV6 Address------------------"
			ripv = re.search(r'[a-fA-F\d]{4}::\d{1}',ap,re.M)
			if ripv:
				ripv=str(ripv.group())
				print ripv

			print "------------------------Name------------------"
			rn1=''
			rname = re.search(ur'\s*Name\s*:\s*(.*)',ap,re.M)
			if rname:
		
				rname=str(rname.group())
				if rname:
					rn = rname.split(':')
					rn1=rn[1]
					print rn1

			print "----------------------State------------------"
			rs=''
			rst = re.search(ur'\s*State\s*:\s*(.*)',ap,re.M)
			if rst:
				rst=str(rst.group())
				if rst:
					rs = rst.split(':')
					rs = rs[1]
					print rs

			
			print "------------------------Tunnel and Secmode------------------"	
			tv=''
			sv=''
			rtn = re.search(ur'\s*Tunnel/Sec Mode\s.*',ap,re.M)
			if rtn:
				#print rtn.group()
				rtn=str(rtn.group())
				if rtn:
					rt = rtn.split(':')
					tsk=rt[0]#key
					tsv=rt[1]#val
					#print tsk
					tk1=tsv.split('/')
					tv=tk1[0]
					print tv
					sv=tk1[1]
					print sv

			print "---------------------Mesh Role------------------"
			rmr1=''
			rmr = re.search(ur'\s*Mesh Role\s*:\s*(.*)',ap,re.M)
			if rmr:
				rmr=str(rmr.group())
				if rmr:
					rmr1 = rmr.split(':')
					rmr1 = rmr1[1]
					print rmr1

			print "---------------------PSK------------------"
			rp1=''
			rp = re.search(ur'\s*PSK\s*:\s*(.*)',ap,re.M)
			if rp:
				rp=str(rp.group())
				if rp:
					rp1=rp.split(':')
					rp1 = rp1[1]
					print rp1

			print "----------------------Timer------------------"
			rt1=''
			rt = re.search(ur'\s*Timer\s*:\s*(.*)',ap,re.M)
			if rt:
				rt=str(rt.group())
				if rt:
					rt1=rt.split(':')
					rt1 = rt1[1]
					print rt1

			print "---------------------HW Version------------------"
			hk=re.search(r'(HW)',ap,re.I)	
			hardval=''
			if hk:
				hardkey=str(hk.group())
				#print hardkey
			hv=re.search(r'(\s[0-9]{1,2}.[0-9]{1}.[0-9]{1}.[0-9]{1}\s)',ap,re.I)
			if hv:
				hardval=str(hv.group())
				print hardval

			print "---------------------SW Version------------------"
			rsw1=''
			rsw = re.search(ur'\s*HW/SW Version\s*:\s*(.*)',ap,re.I)
			if rsw:
				rsw=str(rsw.group())
				if rsw:
					rsw1=rsw.split('/')
					rsw1 = rsw1[2]
					print rsw1
			
			print "---------------------Model------------------"			
			mdv=re.search(r'(Model.*)',ap,re.I)
			modelval=''
			serialval=''
			if mdv:	
				#print mdv.group()
				s=str(mdv.group())
				ms1=s.split(': ')
				mskey=ms1[0]  #left string keys
				#print mskey
				mskey1=mskey.split('/')
				modelkey=mskey1[0]	
				#print mk
				serialkey=mskey1[1]
				#print sk
		
				mvkey=ms1[1]  ##right string value
				#print mvkey		
				mv1=mvkey.split('/')
				modelval=mv1[0]	#msval=ms1[1]	
				#print mv
				serialval=mv1[1]
				#print sv
		
				#print modelkey
				print modelval
				#print serialkey
				print serialval

			self.res.execute("insert into trying1 values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');" % (rmac,rip,ripv,rn1,rs,tv,sv,rmr1,rp1,rt1,hardval,rsw1,modelval,serialval))
			#self.cursor.execute(self.res1)
			self.db.commit()

		#print "done"

obj = Datacls()
obj.filepar()
print "--------Done------------"		





