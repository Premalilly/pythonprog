#!usr/bin/python

dict1 = { }
class Findword:
	def __init__(self):
		self.dict1={'name':'riya','age':'25','salary':'15000'}
		print "dict contains\n",self.dict1
	def findKey(self):
		res1 = raw_input("Enter the key to get value:\n")
		if res1 in self.dict1:
			print self.dict1[res1]
		else:
			res2 = raw_input("Enter the value to add key:\n")
			self.dict1[res1]=res2
			print self.dict1


obj = Findword()
obj.findKey()





















