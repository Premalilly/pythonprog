#!/usr/bin/env python
import os
from datetime import datetime
from dateutil.relativedelta import relativedelta # $ pip install python-dateutil

three_months_ago = datetime.now() - relativedelta(months=3)
file_time = datetime.fromtimestamp(os.path.getmtime('/home/asm'))
if file_time < three_months_ago:
    print("%s is older than 3 months" % (three_months_ago))


