#!/usr/bin/python
import re
import sys

sfile1 = sys.argv[1]
dfile2 = sys.argv[2]

class MatchingClass:
	def __init__(self,sfile1,dfile2):
		self.file2 =open(sfile1)
		self.file1 =open(dfile2)

		self.f1=open("match1",'w+')                            #matching status same
		self.ff2=open("match2",'w+')                           #matching status anything   
		self.f3=open("match3",'w+')                            #matching status differs  
		self.f4=open("match4",'w+')                            #lines present in first but not second
		self.f5=open("match5",'w+') 			       #lines present in first but not second
		self.f6=open("match6",'w+')


		self.dkey1=''
		self.dval1=''
		self.dkey2=''
		self.dval2=''
		self.dict1={}
		self.dict2={}
		self.list1 = []
		self.list2 = []


	def compareFiles(self):
		print "-------source file count--2460------"
		try:
			count1=0
			for line in self.file2:
				f2 = re.match(r'(tempest(.*))',line,re.M)
				if f2:
					#print f2.group()
					s1 = str(f2.group().strip())
					s2= s1.split(' ... ')
					#print s2[0]	
					#print s2[1]
					self.dkey1 = s2[0]
					self.dval1 = s2[1]
					self.dict1[self.dkey1] = self.dval1
					a = str(self.dkey1) + str(self.dval1)
					self.list1.append(a)
					count1 = count1 + 1
			print count1
	

		except IndexError:
			#print "Out of lines"
			print count1	
		#print self.dict1
		#print self.list1

		print "-------destination file count---2059-----"
		count2 = 0
		for lines in self.file1:
			findobj = re.match(r'(tempest(.*))',lines,re.I)
			if findobj:
				#print findobj.group()
				d1 = str(findobj.group().strip())
				d2= d1.split(' ... ')
				#print d2[1]
				self.dkey2 = d2[0]
				self.dval2 = d2[1]
				self.dict2[self.dkey2] = self.dval2
				b = str(self.dkey2) + str(self.dval2)
				self.list2.append(b)
				count2 = count2 +1
		print count2
		#print self.dict2
		#print self.list2


		print "-tempest'to matching status same (both are 'ok' or both are 'FAIL')-1663-"
		countt = 0
		for i in self.list1:
			for j in self.list2:
				if i==j:
					#print i
					self.f1.writelines(i+ '\n')
					countt = countt + 1
		self.f1.close()
		print countt


		print "- matching status differs (one file have 'ok' and another has 'FAIL')-221-"
		count4 = 0
		for i in self.dict1:
			for j in self.dict2:
				if i==j:
					if self.dict1[i] != self.dict2[j]:
						#print i
						#print type(i)
						self.ff2.writelines(i+'\n')
						count4 = count4 + 1
		self.ff2.close()
		print count4


		print "-matching status may be anything (the status is neither 'ok' not 'FAIL'-1884"
		count = 0
		for i in self.dict1:
			for j in self.dict2:
				if i==j:
					#print i
					self.f3.writelines(i+'\n')
					count = count + 1
		self.f3.close()
		print count


		print "------matching status may be anything---87--"
		count5 = 0
		for i in self.dict1:
			for j in self.dict2:
				if(i==j):
					if((self.dict1[i]!='ok')&(self.dict1[i]!='FAIL'))&((self.dict2[j]!='ok')&(self.dict2[j]!='FAIL')):
						#print i,dict1[i]
						count5=count5+1
						self.f4.writelines(i+'\n')
			    
		self.f4.close()
		print count5


		print "---matching status available in first not in second--576--"
		count6=0
		for i in self.dict1:
			if i in self.dict2:
				continue
			else:
				count6=count6+1
				self.f5.writelines(i+'\n')
		      		#print i
		self.f5.close()
		print count6


		print "--matching status available in second but not in first-175-"		
		count7=0
		for j in self.dict2:
			if j in self.dict1:
				continue
			else:
				#print j
				self.f6.writelines(j+'\n')
				count7=count7+1
		self.f6.close()
		print count7
		     		

obj = MatchingClass(sfile1,dfile2)
obj.compareFiles()


			


