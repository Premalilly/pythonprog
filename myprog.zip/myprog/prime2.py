
def isPrime(a,b):  
    for num in range(a,b):
	prime = True
	for i in range(2,num):
		if (num % i==0):
			prime = False
	if prime:
		print num
isPrime(2, 30)	
