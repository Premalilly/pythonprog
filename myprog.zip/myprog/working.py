#!/usr/python/bin
import re
import MySQLdb

with open("/home/asm/Downloads/diag.out", "r") as file1:
    list = []
    
    for line in file1:
           result = re.match("----- APmgr info: apmgrinfo -a", line , re.M|re.I)
           if result:
             for line in file1:
               list.append(line)
               result2 = re.match("----- Disconnected APs: wlaninfo --all-disc-ap -l 3", line , re.M|re.I)
               if result2:
                  break

for line in list:
     print line
