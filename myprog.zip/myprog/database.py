import re
import MySQLdb

db = MySQLdb.connect(host="localhost",    
                     user="root",         
                     passwd="root",  
                     db="program1")        


cursor = db.cursor()


f1 = open("/home/asm/Downloads/app.txt", "r").read()
print "--------------------IPV4Address-------------------------"
rip = re.compile(r'/\s\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s/')
bip = re.findall(rip,f1)
#print b
for a in bip:
	print a[1:-1]
	"""res1= ("insert into exampl1(IPv4Address) values ('%s');" %(a[1:-1]))
	cursor.execute(res1)
	db.commit()"""

print "_____________________MACAddress___________________________"
rmac = re.compile(ur'([0-9a-f]{2}(?::[0-9a-f]{2}){5})', re.IGNORECASE)
bmac = re.findall(rmac,f1)
for mac in bmac:
	print mac
	"""res1= ("insert into exampl1(MACAddres) values ('%s');" %(mac))
	cursor.execute(res1)
	db.commit()"""

print "___________________NAME___________________________"
rname = re.compile(ur'\s*Name\s*:\s*(.*)',re.I)
bname = re.findall(rname,f1)
for nam in bname:
	print nam

print "____________________TUNNEL____________________________________"
rtn = re.compile(ur'\s*Tunnel/Sec Mode\s*:\s*(.*)',re.I)
btn = re.findall(rtn,f1)
for tn in btn:
	print tn[0:-6]

print "______________________SEC MODE__________________________________"
rsc = re.compile(ur'\s*Tunnel/Sec Mode\s*:\s*(.*)',re.I)
bsc = re.findall(rsc,f1)
for sc in bsc:
	sc1 =sc.split('/')
	print sc1[1]

print "______________________STATE__________________________________"
rst = re.compile(ur'\s*State\s*:\s*(.*)',re.I)
bst = re.findall(rst,f1)
for st in bst:
	print st
	
print "_____________________MESH ROLE___________________________________"
rmr = re.compile(ur'\s*Mesh Role\s*:\s*(.*)',re.I)
bmr = re.findall(rmr,f1)
for mr in bmr:
	print mr

print "___________________PSK_____________________________________"
rp = re.compile(ur'\s*PSK\s*:\s*(.*)',re.I)
bp = re.findall(rp,f1)
for psk in bp:
	print psk

print "___________________TIMER_____________________________________"
rt = re.compile(ur'\s*Timer\s*:\s*(.*)',re.I)
bt = re.findall(rt,f1)
for tm in bt:
	print tm

print "__________________HW VERSION______________________________________"
rhw = re.compile(ur'\s*HW/SW Version\s*:\s*(.*)/',re.I)
bhw = re.findall(rhw,f1)
for hw in bhw:
	print hw

print "___________________SW VERSION_____________________________________"
rsw = re.compile(ur'\s*HW/SW Version\s*:\s*(.*)',re.I)
bsw = re.findall(rsw,f1)
for sw in bsw:
	sw1 = sw.split('/')
	print sw1[1]

print "___________________MODEL_____________________________________"
rm = re.compile(ur'\s*Model/Serial Num\s*:\s*(.*)/',re.I)
bm = re.findall(rm,f1)
for md in bm:
	print md

print "____________________SERIAL NUM____________________________________"
rs = re.compile(ur'\s*Model/Serial Num\s*:\s*(.*)',re.I)
bs = re.findall(rs,f1)
for sr in bs:
	sr1 = sr.split('/')
	print sr1[1]

print "____________________IPV6 ADDRESS____________________________________"
ripv = re.compile(r'[a-fA-F\d]{4}::\d{1}')
bipv = re.findall(ripv,f1)
for ipv in bipv:
	print ipv
#IPv6Address


print "___________________DATABASE CONNECTION______________________________"

if len(bmac)==len(bip)==len(bipv)==len(bname)==len(bst)==len(btn)==len(bsc)==len(bmr)==len(bp)==len(bt)==len(bhw)==len(bsw)==len(bm)==len(bs):
	for i in range(len(bmac)):
		res1= ("insert into exampl1 values ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');" %(bmac[i],bip[i][1:-1],bipv[i],bname[i],bst[i],btn[i][0:-6],bsc[i][1],bmr[i],bp[i],bt[i],bhw[i],bsw[i][1],bm[i],bs[i][1]))
		cursor.execute(res1)
		db.commit()
	#print "done"

print "**************"







