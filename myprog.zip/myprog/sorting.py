#!/usr/bin/python
list1 = []
array = []

def sort(list1):
         print list1
         for i in range(0,99):
                if ( list1[i] > list1[i+1] ):
                    array.append(list1[i])
                else:
                    array.append(list1[i+1])
                



sort([12 , 34 , 45 , 1 , 100 , 67 , 90 ]) 

print array
