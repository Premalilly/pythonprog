

list1 = [1, 6, 7, 8, 2, 18, 3, 5, 10, 15, 9]
print(list1)
num = 0
for x in list1:
   # num+=1
	num = num+1
for i in range(num):
    for j in range(1, num-i):
        if list1[j-1] > list1[j]:
             (list1[j-1], list1[j]) = (list1[j], list1[j-1])
print(list1)
