import requests as r
import json

#g = r.get("http://122.181.186.42:9200")
#print g.text
#g = r.post("http://122.181.186.42:9200/prema", {'name' : 'prema'})
#print g.text
#g = r.get("http://122.181.186.42:9200/prema")
#json_str = g.text
g = r.get("http://localhost:9200/schools")
json_str = g.text 
json_dict = json.loads(json_str)
#print json_dict
var1 = json.dumps(json_dict,indent = 5)
#print var1
print json_dict.keys()
#print json_str['schools']['setting']['index']['uuid']
